
var app = app || {};


$(function() {
    new app.portfolioView();

});